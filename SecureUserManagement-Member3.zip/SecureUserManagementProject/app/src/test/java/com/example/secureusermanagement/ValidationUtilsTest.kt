package com.example.secureusermanagement

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ValidationUtilsTest {
    @Test fun acceptsValidRegistration() {
        assertNull(ValidationUtils.validateRegistration("alice_01", "alice@example.edu", "correct horse battery", "correct horse battery"))
    }

    @Test fun rejectsShortPassword() {
        assertEquals("Password must be at least 12 characters.", ValidationUtils.validateRegistration("alice", "alice@example.edu", "short123", "short123"))
    }

    @Test fun rejectsMalformedEmailAndUsername() {
        assertEquals("Enter a valid email address.", ValidationUtils.validateRegistration("alice", "not-an-email", "correct horse battery", "correct horse battery"))
        assertEquals("Username may use letters, numbers, dot, underscore, and hyphen.", ValidationUtils.validateRegistration("alice space", "alice@example.edu", "correct horse battery", "correct horse battery"))
    }

    @Test fun rejectsPasswordMismatchAndBlankLogin() {
        assertEquals("Passwords do not match.", ValidationUtils.validateRegistration("alice", "alice@example.edu", "correct horse battery", "different password"))
        assertEquals("Username is required.", ValidationUtils.validateLogin(" ", "notempty"))
    }
}
